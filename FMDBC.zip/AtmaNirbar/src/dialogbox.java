/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rohithputha
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rohithputha
 */

import java.util.ArrayList;
import javax.swing.*;  
public class dialogbox {  
JFrame f;


dialogbox(String message){  
    f=new JFrame();  
    JOptionPane.showMessageDialog(f,message);  
}  



}  

