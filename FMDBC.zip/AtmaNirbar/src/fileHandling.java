/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chsra
 */
import java.util.*;
import java.io.*;

public class fileHandling {
    
    public fileHandling()
    {
       
    }
    public static void main(String args[])
    {
        dataWriting dw=new dataWriting();
        dw.barChemical("001234","Methanol");
    }
    
}
